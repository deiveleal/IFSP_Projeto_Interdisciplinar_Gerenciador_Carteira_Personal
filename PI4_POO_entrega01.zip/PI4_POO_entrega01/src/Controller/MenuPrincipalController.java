package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuPrincipalController {

    @FXML
    private Button bt_gerencia_aluno;

    @FXML
    private Button bt_gerencia_exercicios;

    @FXML
    private Button bt_acompanhamento;

}