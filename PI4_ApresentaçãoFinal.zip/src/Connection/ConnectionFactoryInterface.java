package Connection;

import java.sql.Connection;

/**
 * @author carolina
 * @author deive
 */

public interface ConnectionFactoryInterface {
    public Connection getConnection();
}
