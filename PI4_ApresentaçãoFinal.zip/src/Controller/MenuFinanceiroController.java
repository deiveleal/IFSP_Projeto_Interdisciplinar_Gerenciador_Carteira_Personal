package Controller;

import Model.ModelScreen.CadastraPlanoScr;
import Model.ModelScreen.MenuFinanceiroScr;
import Model.ModelScreen.MenuPrincipalScr;
import Model.Util;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class MenuFinanceiroController implements Initializable {

    @FXML
    private Button bt_cadastrar_aluno;
    @FXML
    private Button bt_avaliacao;
    @FXML
    private Button bt_medidas;
    @FXML
    private Button bt_plano;
    @FXML
    private Button bt_menu_iniciar;
    @FXML
    private Button bt_sair;

    Util util = new Util();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        // Implementações do botão plano
        bt_plano.setOnMouseClicked((MouseEvent e) -> {
            CadastraPlanoScr cadastraPlano = new CadastraPlanoScr();
            try {
                cadastraPlano.start(new Stage());
                fechaJanela();
            } catch (Exception ex) {
                Logger.getLogger(MenuFinanceiroController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        bt_plano.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                CadastraPlanoScr cadastraPlano = new CadastraPlanoScr();
                try {
                    cadastraPlano.start(new Stage());
                    fechaJanela();
                } catch (Exception ex) {
                    Logger.getLogger(MenuFinanceiroController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        bt_menu_iniciar.setOnMouseClicked((MouseEvent e) -> {
            MenuPrincipalScr menuPrinc = new MenuPrincipalScr();
            try {
                menuPrinc.start(new Stage());
                fechaJanela();
            } catch (Exception ex) {
                Logger.getLogger(MenuFinanceiroController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        bt_menu_iniciar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                MenuPrincipalScr menuPrinc = new MenuPrincipalScr();
                try {
                    menuPrinc.start(new Stage());
                    fechaJanela();
                } catch (Exception ex) {
                    Logger.getLogger(MenuFinanceiroController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        bt_sair.setOnMouseClicked((MouseEvent e) -> {
            util.voltaTelaLogin();
            fechaJanela();
        });
        bt_sair.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER) {
                util.voltaTelaLogin();
                fechaJanela();
            }
        });
    }

    private void fechaJanela() {
        MenuFinanceiroScr.getStage().close();
    }
;
}
