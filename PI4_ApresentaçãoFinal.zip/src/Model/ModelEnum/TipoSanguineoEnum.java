package Model.ModelEnum;

public enum TipoSanguineoEnum {
    A, O, AB, B;
}
