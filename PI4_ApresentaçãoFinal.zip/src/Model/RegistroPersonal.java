package Model;

public class RegistroPersonal extends RegistroPessoa {


}
