package Model.ModelScreen;

import javafx.application.Application;
import javafx.stage.Stage;

abstract class Screen extends Application {

    public void start(Stage stage) throws Exception {
    }

    public static Stage getStage() {
        return null;
    }

    public static void setStage(Stage stage) {
    }
}
